<template>
  <div class="app-layout">
    <LeftMenu @navigate="onNavigate" class="leftMenu" />
    <Header class="header" />

    <div class="dashboard-content">
      <h1 class="welcome-title">HR Dashboard 📊</h1>
      <p class="role-info">
        Welcome back, {{ firstname }}. Here is a summary of all employee ID card progress statuses.
      </p>

      <div class="summary-grid">
        <template v-if="Object.keys(idStats).length">

          <div class="status-card clickable" @click="goToDetails('all')">
            <div class="status-icon">👥</div>
            <div class="status-info">
              <div class="status-number">{{ idStats.totalEmployees || 0 }}</div>
              <div class="status-label">All Employees</div>
            </div>
          </div>

          <div class="status-card for-schedule clickable" @click="goToDetails('schedule')">
            <div class="status-icon">📅</div>
            <div class="status-info">
              <div class="status-number">{{ idStats.forSchedule || 0 }}</div>
              <div class="status-label">For Schedule</div>
            </div>
          </div>

          <div class="status-card approval clickable" @click="goToDetails('approval')">
            <div class="status-icon">⏳</div>
            <div class="status-info">
              <div class="status-number">{{ idStats.scheduleRequests || 0 }}</div>
              <div class="status-label">For Approval</div>
            </div>
          </div>

          <div class="status-card scheduled clickable" @click="goToDetails('scheduled')">
            <div class="status-icon">📝</div>
            <div class="status-info">
              <div class="status-number">{{ idStats.scheduled }}</div>
              <div class="status-label">Scheduled (For Capture)</div>
            </div>
          </div>

          <div class="status-card captured clickable" @click="goToDetails('captured')">
            <div class="status-icon">📸</div>
            <div class="status-info">
              <div class="status-number">{{ idStats.capturedPendingAFIS }}</div>
              <div class="status-label">Captured</div>
            </div>
          </div>

          <div class="status-card validated clickable" @click="goToDetails('adjudication')">
            <div class="status-icon">✅</div>
            <div class="status-info">
              <div class="status-number">{{ idStats.pendingAdjudication }}</div>
              <div class="status-label">Adjudication</div>
            </div>
          </div>
          <div class="status-card for-printing clickable" @click="goToDetails('for-printing')">
            <div class="status-icon">🖨️</div>
            <div class="status-info">
              <div class="status-number">{{ idStats.readyForPrinting }}</div>
              <div class="status-label">For Printing</div>
            </div>
          </div>

          <div class="status-card for-activation clickable" @click="goToDetails('active-cards')">
            <div class="status-icon">🔓</div>
            <div class="status-info">
              <div class="status-number">{{ idStats.printed || 0 }}</div>
              <div class="status-label">For Activation</div>
            </div>
          </div>

          <div class="status-card active-cards clickable" @click="goToDetails('active-cards')">
            <div class="status-icon">💳</div>
            <div class="status-info">
              <div class="status-number">{{ idStats.activeCards || 0 }}</div>
              <div class="status-label">Active Cards</div>
            </div>
          </div>
        </template>
        <template v-else>
          <p>Loading stats...</p>
        </template>
      </div>

    </div>
  </div>
</template>

<script setup>
  import { ref, onMounted, computed } from "vue";
  import { useRouter } from "vue-router";
  import LeftMenu from "@/components/LeftMenu.vue";
  // Assuming Header is in '@/components/Header.vue' based on common structure
  //import Header from "@/components/Header.vue";
  import DialogBox from "@/components/DialogBox.vue";
  import LoadingDialog from "@/components/LoadingDialog.vue";
  import { useAuthStore } from "@/stores/auth";
  import api from "@/api";

  // --- Dialog & Loading ---
  const showDialog = ref(false);
  const dialogTitle = ref("");
  const dialogMessage = ref("");
  const isLoading = ref(false);

  // --- Router ---
  const router = useRouter();

  // --- Auth store & user data ---
  const auth = useAuthStore();
  const firstname = computed(() => auth.firstName ?? "User");
  const username = computed(() => auth.username ?? "User");
  const userType = computed(() => Number(auth.userType ?? 1));

  // --- Status stats ---
  const idStats = ref({
    totalEmployees: 0,
    forSchedule: 0,         // Status 0
    scheduleRequests: 0,    // Status 7
    scheduled: 0,           // Status 1
    captured: 0,            // Status 2
    pendingAdjudication: 0, // Status 3
    readyForPrinting: 0,    // Status 4
    forActivation: 0,       // Status 5 🆕
    activeCards: 0,         // Status 6 🆕
  });

  // --- Navigation state ---
  const current = ref("Dashboard");
  const onNavigate = (item) => {
    current.value = item;
  };

  // 🎯 UPDATED: Function to handle card click and redirection
  const goToDetails = (statusType) => {
    let targetTab = "";

    if (statusType === 'all') targetTab = "All Employees";
    if (statusType === 'schedule') targetTab = "Schedule Biometrics";
    if (statusType === 'approval') targetTab = "For Approval";
    if (statusType === 'scheduled') targetTab = "Scheduled";
    if (statusType === 'captured') targetTab = "Captured Biometrics";
    if (statusType === 'adjudication') targetTab = "Adjudication";
    if (statusType === 'validated') targetTab = "Generate Cards";
    if (statusType === 'for-printing') targetTab = "Generate Cards";
    if (statusType === 'active-cards') targetTab = "Activate Cards";

    if (!targetTab) targetTab = "All Employees";

    // Use the PATH that we know works in your LeftMenu
    router.push({
      path: "/manage-employee-ids",
      query: { tab: targetTab }
    });
  };

  // --- Load user + stats on mount ---
  onMounted(async () => {
    if (typeof auth.loadUser === "function") {
      await auth.loadUser();
    }
    loadStats();
  });

  // --- Fetch ID stats ---
  async function loadStats() {
    try {
      isLoading.value = true;
      const res = await api.get("/hr/id-stats");
      console.log("API Response Stats:", res.data); // 🔍 Check your console with F12
      idStats.value = res.data;
    } catch (err) {
      console.error("AxiosError:", err);
      if (err.response) {
        console.error("Status:", err.response.status);
        console.error("Data:", err.response.data);
      } else if (err.request) {
        console.error("No response received from server", err.request);
      } else {
        console.error("Axios setup error:", err.message);
      }

      // Log out the user on error if there's no response data
      if (!err.response && typeof auth.logout === "function") {
        auth.logout(); // this should clear user data and redirect to login
      } else {
        showDialog.value = true;
        dialogTitle.value = "Error";
        dialogMessage.value = "Failed to load dashboard stats. Please log in again.";
      }
    } finally {
      isLoading.value = false;
    }
  }
</script>

<style scoped>
  /* --- MODERN APP LAYOUT --- */
  .app-layout {
    display: grid;
    /* Aligned with the 280px sidebar width */
    grid-template-columns: 280px 1fr;
    grid-template-rows: auto 1fr;
    min-height: 100vh;
    background-color: #f4f7f9;
  }

  .leftMenu {
    grid-column: 1;
    grid-row: 1 / span 2;
    z-index: 100;
  }

  .header {
    grid-column: 2;
    grid-row: 1;
    z-index: 90;
  }

  .dashboard-content {
    grid-column: 2;
    grid-row: 2;
    padding: 40px;
    box-sizing: border-box;
    font-family: 'Inter', sans-serif;
    overflow-y: auto;
  }

  .welcome-title {
    font-size: 2.25rem;
    /* Aligned with Left Menu Official Blue */
    color: #06195e;
    margin-bottom: 8px;
    font-weight: 800;
    letter-spacing: -0.025em;
  }

  .role-info {
    margin-bottom: 40px;
    color: #718096;
    font-size: 1.1rem;
    font-weight: 400;
  }

  /* --- SUMMARY GRID --- */
  .summary-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 24px;
    margin-bottom: 40px;
  }

  /* --- MODERN STATUS CARDS --- */
  .status-card {
    background: white;
    padding: 24px;
    border-radius: 16px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    border: 1px solid rgba(0, 0, 0, 0.05);
    /* Changed from border-top to border-left to match the sidebar's active indicator */
    border-left: 6px solid #e2e8f0;
    position: relative;
    overflow: hidden;
  }

    .status-card.clickable {
      cursor: pointer;
    }

    .status-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1);
    }

  .status-icon {
    font-size: 2.2rem;
    width: 64px;
    height: 64px;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #f8fafc;
    border-radius: 14px;
  }

  .status-info {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    text-align: right;
  }

  .status-number {
    font-size: 2.5rem;
    font-weight: 800;
    color: #06195e; /* Consistent Navy */
    line-height: 1;
  }

  .status-label {
    font-size: 0.85rem;
    color: #4a5568;
    margin-top: 8px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.05em;
  }

  /* --- COLOR CODING (Border-Left consistent with Sidebar Active State) --- */
  .status-card.for-schedule {
    border-left-color: #ecc94b;
  }
  /* Yellow */
  .status-card.approval {
    border-left-color: #4299e1;
  }
  /* Blue */
  .status-card.scheduled {
    border-left-color: #667eea;
  }
  /* Indigo */
  .status-card.captured {
    border-left-color: #48bb78;
  }
  /* Green */
  .status-card.validated {
    border-left-color: #38b2ac;
  }
  /* Teal */
  .status-card.for-printing {
    border-left-color: #9f7aea;
  }
  /* Purple */
  .status-card.active-cards {
    border-left-color: #f56565;
  }
  /* Red */

  /* RESPONSIVENESS */
  @media (max-width: 1024px) {
    .app-layout {
      grid-template-columns: 80px 1fr;
    }

    .dashboard-content {
      padding: 25px;
    }
  }

  @media (max-width: 768px) {
    .app-layout {
      grid-template-columns: 1fr;
    }

    .leftMenu {
      display: none;
    }

    .summary-grid {
      grid-template-columns: 1fr;
    }
  }
</style>
